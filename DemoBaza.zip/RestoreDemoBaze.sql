/*
1. RESTORA DEMO BAZE SA BACKUP FAJLA

Pretpostavka je da ste preuzeli backup demo baze podataka
i smestili ga u direktorijum C:\DemoBaza

 Prva opcija je restore baze i njenih fajlova na originalnu lokaciju koja je:
 C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA 
   Sledeci skript ce funkcionisati ako imate instaliran 
   SQL Server 2017 sa default opcijama 
*/
USE master;
GO
RESTORE DATABASE WWI_SQL 
FROM DISK = N'C:\DemoBaza\WWI_SQL.bak';

/*
   U slucaju da imate drugaciju verziju SQL Servera ili zelite
   da izmenite lokaciju data i log fajla demo baze to se moze uraditi na sledeci nacin:
   Ako, na primer, zelimo da izmenimo lokaciju data i log fajlova
   na direktorijum D:\TestBaza koristimo sledeci skript:
*/
USE master;
GO
RESTORE DATABASE [WWI_SQL] 
FROM  DISK = N'C:\DemoBaza\WWI_SQL.bak' 
WITH
MOVE N'WWI_SQL' TO N'D:\TestBaza\WWI_SQL.mdf',  -- nova lokacija
MOVE N'WWI_SQL_log' TO N'D:\TestBaza\WWI_SQL_log.ldf' -- nova lokacija
GO
-- Da bi skript funkcionisao folder D:\TestBaza, ili bilo koji drugi 
-- koji upisete, mora predhodno biti kreiran.

